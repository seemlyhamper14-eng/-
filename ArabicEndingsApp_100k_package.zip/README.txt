Arabic Endings Full Package - ~100k dataset
Generated entries: 100000
Includes:
- app/src/main/assets/words_prepared.csv (CSV with word,word_rev)
- app/src/main/assets/arabic_words.db (SQLite DB with FTS5 if available)
- web/backend/main.py (FastAPI example to query the DB)
- frontend placeholder

How to use:
1. Open the Android project in Android Studio, place the DB in assets (already included), build APK.
2. Or run the FastAPI backend: python web/backend/main.py and use the /search?end=ين endpoint.
