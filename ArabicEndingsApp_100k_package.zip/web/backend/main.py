from fastapi import FastAPI, Query
import sqlite3
from typing import List
import uvicorn

app = FastAPI(title="Arabic Endings API")

DB_PATH = "/mnt/data/ArabicEndingsApp_100k/app/src/main/assets/arabic_words.db"

def query_rev_prefix(rev_prefix: str, limit: int = 100):
    conn = sqlite3.connect(DB_PATH)
    conn.create_function("REVERSE", 1, lambda s: s[::-1] if s else s)
    cur = conn.cursor()
    try:
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='fts_words'")
        if cur.fetchone():
            q = "SELECT word FROM fts_words WHERE word_rev MATCH ? LIMIT ?"
            param = rev_prefix + "*"
            cur.execute(q, (param, limit))
            rows = [r[0] for r in cur.fetchall()]
        else:
            q = "SELECT word FROM words WHERE word_rev LIKE ? LIMIT ?"
            cur.execute(q, (rev_prefix + '%', limit))
            rows = [r[0] for r in cur.fetchall()]
    finally:
        conn.close()
    return rows

@app.get('/search', response_model=List[str])
def search(end: str = Query(..., min_length=1), limit: int = 100):
    rev = end[::-1]
    results = query_rev_prefix(rev, limit)
    return results

if __name__ == '__main__':
    uvicorn.run(app, host='0.0.0.0', port=8000)
